            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright © <a class = "customA" href="http://localhost/JessShoppe/index.php">Jess Shoppe</a>. All rights reserved.</span>
                    </div>
                </div>
            </footer>
           
		<!-- End of Content Wrapper frop topbar.php -->
        </div>
     <!-- End of Page Wrapper --> 
	 </div>
    