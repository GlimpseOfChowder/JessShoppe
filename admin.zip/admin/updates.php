<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>
<?php include 'includes/topbar.php'; ?>

    <title>Updates</title>
	<?php
        include 'includes/dbh.inc.php';

			if(isset($_SESSION["useruid"])) {
			
			$sql = "SELECT * FROM users WHERE usersId = '".$_SESSION['userid']."'";
			$result = mysqli_query($conn, $sql);
				
			while($row=mysqli_fetch_array($result)) {
				
				if($row["usertype"] == "admin"){
	?>

       <!-- Begin Page Content -->
       <div class="container-fluid">

           <!-- DataTables -->
		   <div class="d-sm-flex align-items-center justify-content-between mb-4">
           	  <a href="#addText" data-toggle="modal" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Add New Post</a>
           </div>
           <div class="card shadow mb-4">
               <div class="card-header py-3">
                   <h6 class="m-0 font-weight-bold text-primary">Updates</h6>
               </div>
               <div class="card-body">
                   <div class="table-responsive">
                       <table class="table table-bordered" id="shopInfo" width="100%" cellspacing="0">
                           <thead>
                               <tr>
								   <th hidden>ID</th>
								   <th>Date</th>
                                   <th>Title</th>
								   <th>Content</th>
                                   <th>Photo</th>
                                   <th></th>
                               </tr>
                           </thead>
						   <tbody>
                           <?php
								include 'includes/dbh.inc.php';
										
								$sql = "SELECT * FROM updates";
								$result = mysqli_query($conn, $sql);
										
								while($row=mysqli_fetch_array($result)){
									$date = new DateTime($row['date_posted']);
							?>
							<tr>
								<td hidden><?php echo $row['updates_id']; ?></td>
								<td><?php echo $date->format('h:i a - M d Y '); ?></td>
								<td><?php echo $row['title']; ?></td>
								<td><?php echo $row['content']; ?></td>
                                <td><img src="upload/<?php echo $row['photos'];?>" class="updates_image" width="100" height="100"></td>
								<td style="text-align: center">
								<!-- Edit Button -->
								<a href="#editPost" class="text-white editPost" data-toggle="modal"><button class='btn-edit btn-circle btn-sm'><i class='fas fa-edit'></i></button></a>
								<!-- (Delete Button) 
								<a href='#deleteModal' class="text-white delete" data-toggle="modal"><button class='btn-block btn-circle btn-sm'><i class='fas fa-ban text-white'></i></button></a> -->
								</td>
							</tr>
                        <?php } ?>
						</tbody>
             		</table>
          		</div>
      		</div>
  		</div>
	<!-- End of container-fluid -->
	</div>  
	<!-- End of Main Content from topbar.php -->
	</div>
	
	<?php			
						}
					}
				}
				else {
			?>	
				<!-- For unwelcome visitors -->			
				<div class = "content-wrapper">
					<div class = "container box-body" style="padding-top: 200px; padding-left: 400px">
						<div class="container-fluid">
							<!-- 404 Error Text -->
							<div class="text-center">
								<div class="error mx-auto" data-text="404">404</div>
								<p class="lead text-gray-800 mb-5">Page Not Found</p>
								<p class="text-gray-500 mb-0">It looks like you found a glitch in the matrix...</p>
								<a href="../index.php" style="color: #f5a6b9">&larr; Back to Homepage</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
					}
			?>

	<!-- Add New Modal-->
    <div class="modal fade" id="addText" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class='modal-header'>
					<h5 class='modal-title'>Add New Post</h5>
					<button type='button' class='close' data-dismiss='modal' aria-label='Close'>
						<span aria-hidden='true'>&times;</span>
					</button>
				</div>
                <div class="modal-body">
					<div class="container-fluid">
						<form method="POST" action="includes/add_updates.php" enctype="multipart/form-data">
							<div class="row">
								<div class="col-lg-10">
									<input type="file" class="form-control" style="padding-bottom: 35px" name="updates_image" placeholder="Image">
								</div>
								<div style="height:54px;"></div>
								<div class="col-lg-10">
									<input type="text" class="form-control" name="title" placeholder="Title">
								</div>
								<div style="height:50px;"></div>
								<div class="col-lg-10">
									<textarea class="form-control" name="content" placeholder="Content.."></textarea>
								</div>
							</div>
						</div>
						<div style="height:10px;"></div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
							<button type="submit" name="add_updates" class="btn btn-primary">Add</a>
						</form>
					</div>
            	</div>
       	 	</div>
    	</div>
	</div> 

	<!-- Edit Modal -->							
	<div class='modal fade' id='editPost' tabindex='-1' role='dialog' aria-hidden='true'>
		<div class='modal-dialog modal-dialog-centered' role='document'>
			<div class='modal-content'>
				<div class='modal-header'>
					<h5 class='modal-title'>Edit Post</h5>
					<button type='button' class='close' data-dismiss='modal' aria-label='Close'>
						<span aria-hidden='true'>&times;</span>
					</button>
				</div>
			<div class='modal-body'>
				<form action="includes/edit_updates.php" method='POST' enctype="multipart/form-data">
					<div class='form-group'>	
						<input type='hidden' name='updates_id' id='updates_id'>	
						<div class="row">
								<div class="col-lg-10">
									<input type="file" class="form-control" style="padding-bottom: 35px" name="updates_image" id="updates_image" placeholder="Image">
								</div>
								<div style="height:54px;"></div>
								<div class="col-lg-10">
									<input type="text" class="form-control" name="update_title" id="update_title" placeholder="Title">
								</div>
								<div style="height:50px;"></div>
								<div class="col-lg-10">
									<textarea class="form-control" name="update_content" id="update_content" placeholder="Content.."></textarea>
								</div>
							</div>
					</div>
			</div>		
			<div class='modal-footer'>
					<button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
					<a href="edit_update.php?id=<?php echo $row['updates_id']; ?>">
						<button type='submit' name='editText' class='btn btn-primary'>Save</button></a>
				</form>
			</div>
			</div>
		</div>
	</div>

<?php include 'includes/footer.php'; ?>
<?php include 'includes/scripts.php'; ?>
	
</body>
</html>